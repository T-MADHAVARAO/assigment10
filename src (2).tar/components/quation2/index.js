import React, { useState, useEffect } from "react";

const UserComponent = () => {
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    profileImage: "",
  });

  useEffect(() => {
    // Fetch all users from the backend when the component mounts
    fetch("http://localhost:3000/users")
      .then((response) => response.json())
      .then((data) => setUsers(data));
  }, []);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setNewUser({ ...newUser, [name]: value });
  };

  const handleAddUser = () => {
    fetch("http://localhost:3000/users", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newUser),
    })
      .then((response) => response.json())
      .then((data) => {
        setUsers([...users, data]);
        setNewUser({ name: "", email: "", profileImage: "" });
      });
  };

  return (
    <div>
      <h1>User Management</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.name} - {user.email} - {user.profileImage}
          </li>
        ))}
      </ul>
      <input
        type="text"
        placeholder="Name"
        name="name"
        value={newUser.name}
        onChange={handleInputChange}
      />
      <br />
      <input
        type="text"
        placeholder="Email"
        name="email"
        value={newUser.email}
        onChange={handleInputChange}
      />
      <br />
      <input
        type="text"
        placeholder="Profile Image URL"
        name="profileImage"
        value={newUser.profileImage}
        onChange={handleInputChange}
      />
      <br />
      <button onClick={handleAddUser}>Add User</button>
    </div>
  );
};

export default UserComponent;
