function getSum(numberArr, target) {
  const numMap = {};

  for (let i = 0; i < numberArr.length; i++) {
    const currentNum = numberArr[i];
    const complement = target - currentNum;
    if (numMap.hasOwnProperty(complement)) {
      return [numMap[complement], i];
    }
    numMap[currentNum] = i;
  }
  return [];
}

// Example usage:
const numberArr = [2, 7, 11, 15];
const target = 9;
const result = getSum(numberArr, target);
console.log(result); 
