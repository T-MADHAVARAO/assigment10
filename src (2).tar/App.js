import UserComponent from "./components/quation2";
import "./App.css";

function App() {
  return <UserComponent />;
}

export default App;
